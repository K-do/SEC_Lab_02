pub mod validator;
pub mod argon2_config;

/// Message send by the server to confirm a successful action
pub const SUCCESS: &str = "OK";